/*
 * Basic responsive mashup template
 * @owner Enter you name here (xxx)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );
var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
require.config( {
	baseUrl: ( config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources"
} );
var qv,app;
require( ["js/qlik"], function ( qlik ) {
	qlik.setOnError( function ( error ) {
		$( '#popupText' ).append( error.message + "<br>" );
		$( '#popup' ).fadeIn( 1000 );
	} );
	$( "#closePopup" ).click( function () {
		$( '#popup' ).hide();
	} );
	qv=qlik;
  app=qlik.openApp('9d358a4e-630b-40d1-bb53-471c47631706',config);

	//var app1 = qlik.openApp('cee469d3-243c-4e9a-8e54-fe32059aa26f', config);
  
    
	app.getObject('QV03','cbvce');
    app.getObject('QV04','JJuAEX');
	    app.getObject('filter1','ryURPkj');
    app.getObject('filter2','JbPnB');
    app.getObject('filter3','AQZyTvm');
    app.getObject('filter4','WkWYVGF');
	
	app.getObject('filter5','XytNdm');
    app.getObject('filter6','VztbDxw');
    app.getObject('filter7','pXhYj');
	app.getObject('filter8','RQrcpF');
    app.getObject('filter9','XytNdm');
    


	//callbacks -- inserted here --
	//open apps -- inserted here --
	//get objects -- inserted here --
	app.getObject('QV01','BWtAcYH');
		app.getObject('QV01Table','2571fcf8-4e9d-47f3-b77d-0763527bbacc');
	app.getObject('QV14','Gdgpph');
	app.getObject('QV15','aWUejhd');
	app.getObject('QV14T','Gdgpph');
	app.getObject('QV15T','aWUejhd');
	app.getObject('QV14TT','Gdgpph');
	app.getObject('QV15TT','aWUejhd');
	app.getObject('QV13','FcjGH');
	app.getObject('QV12','CQmAdMc');
	
	
	app.getObject('QV11','qmvKeu');
	app.getObject('QV10','bjASMXe');
	
	app.getObject('QV09','PUkjg');
	
	
	
	app.getObject('QV08','cWnvSrz');
	app.getObject('QV07','UmqpPn');
	app.getObject('QV05','1763626d-4769-4068-8e51-976a7be35872');
	app.getObject('QV06','vrbNmj');
	
	
	app.getObject('QV02','fPmMcP');
	

	//create cubes and lists -- inserted here --

} );
function openPage(pageName,elmnt,color) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
      //tablinks[i].style.backgroundColor = "";
	    tablinks[i].classList.remove("active");

    }
    document.getElementById(pageName).style.display = "block";
    //elmnt.style.backgroundColor = color;
	  elmnt.classList.add("active");

	
	qv.resize();
  }
  var tabs = document.getElementsByClassName('tablink');

	Array.prototype.forEach.call(tabs, function(tab) {
	tab.addEventListener('click', setActiveClass);
	});

function setActiveClass(evt) {
	Array.prototype.forEach.call(tabs, function(tab) {
		tab.classList.remove('active');
	});
	
	evt.currentTarget.classList.add('active');
}

function exportExcel(objectID){
app.visualization.get(objectID).then(function(vis){
    vis.exportData({format:'OOXML', state: 'A'}).then(function (link) {
        window.open(link);
    });
		});
}
function changeChart(){
if($('#toggleChart').is(":checked")){
$('#QV01Table').css('display','none');
$('#QV01').css('display','block');
	qv.resize();
}
else{
$('#QV01').css('display','none');
$('#QV01Table').css('display','block');
	qv.resize();

}
}
